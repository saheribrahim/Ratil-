// Start the app
load();
